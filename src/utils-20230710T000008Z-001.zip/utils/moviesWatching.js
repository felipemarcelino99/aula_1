export const MOVIESWATCHING = [
  {
    id: "1",
    name: "Wheel Of Time",
    moviesURL: require("../assets/movies/wheel_of_time.png"),
  },
  {
    id: "2",
    name: "Inception",
    moviesURL: require("../assets/movies/inception.png"),
  },
];
